import random
import tkinter as tk
from tkinter import ttk
import subprocess
from PIL import Image, ImageTk

root = tk.Tk()
root.geometry("500x400")
root.title("JvavScript")
root.resizable(False, False)
root.configure(background="aqua")
root.wm_iconbitmap('.pyjs/icon1.ico')

def adss():
    seconds = random.randint(10, 30)
    seconds = seconds * 1000
    root.after(seconds, show_ad)

def show_ad():
    win = tk.Toplevel(root)
    win.geometry("500x380")
    win.title("AD")
    adno = random.randint(1,4)
    image_file = '.pyjs/AD.png' if adno == 1 or adno == 2 else '.pyjs/AD2.png'
    image = tk.PhotoImage(file=image_file)
    background_label = tk.Label(win, image=image)
    background_label.image = image
    background_label.pack()
    win.protocol("WM_DELETE_WINDOW", lambda: [win.destroy(), adss()])

def b1():
    program_path = 'js/jvs/jvs.exe'
    process = subprocess.run(['start',program_path],shell=True)

def b2():
    program_path = 'js/jvson/jvson.exe'
    process = subprocess.run(['start',program_path],shell=True)

styles = ttk.Style()
styles.configure("Accent.TButton", foreground="black", background="aqua", font=("Segoe UI", 12))

buto = ttk.Button(
    root,
    text="Run JvavScript",
    command=b1,
    style="Accent.TButton"
    )
buto.place(x=170, y=50, width=160, height=40)

buto2 = ttk.Button(
    root,
    text="Run Jvson",
    command=b2,
    style="Accent.TButton"
    )
buto2.place(x=170, y=90, width=160, height=40)

tes = tk.Label(
    root,
    text="张浩扬博士的JvavScript",
    font=("Segoe UI", 18),
    background="aqua"
    )
tes.place(x=120, y=5)

tess = tk.Label(
    root,
    text="JvavScript,全球800亿用户的选择",
    font=("Segoe UI", 18, "bold"),
    background="aqua"
    )
tess.place(x=70, y=350)

image = ImageTk.PhotoImage(Image.open('.pyjs/icon1.ico'))
image_label = tk.Label(root, image=image, background="aqua")
image_label.image = image
image_label.place(x=180, y=130)

images = ImageTk.PhotoImage(Image.open('.pyjs/icon2.ico'))
image_labels = tk.Label(root, image=images, background="aqua")
image_labels.image = images
image_labels.place(x=250, y=130)

root.after(0, adss)
root.mainloop()