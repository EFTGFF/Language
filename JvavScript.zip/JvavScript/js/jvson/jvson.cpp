#include <iostream>
#include <windows.h>
#include <list>
#include <string>
#include <fstream>
using namespace std;

int main(){
    SetConsoleTitle("JvavScript Object Notation");
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
    std::cout <<"Start:"<< endl;
    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    string c;
    std::list<string> ml;
    for (;;){
        std::getline(std::cin, c);
        ml.push_back(c);
        if (c == "{\"task\":\"save\"}") 
        { 
            ml.pop_back();
            char* desktopDir = getenv("USERPROFILE");
            if (!desktopDir) {
                std::cerr << "Can't saving file" << endl;
                return 1;
            }
            std::string savePath = std::string(desktopDir) + "\\Desktop\\save.jvson";
            std::ofstream outfile(savePath.c_str()); 
            if (outfile.is_open()) {
                for (const auto& item : ml) {
                    outfile << item << "\n";  
                }
                outfile.close();
                SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
                std::cout << ">>Save to " << savePath << endl;
                SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
            }
        }
    }
}
