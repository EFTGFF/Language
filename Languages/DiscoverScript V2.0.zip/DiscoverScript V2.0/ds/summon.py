while True:
    x = input("fuc\n")
    y = input("run\n")
    ass = input("who\n")
    z = input("easy\n")
    if ass == "m" :  
        print("        else if (x == \"" + x +"()\") {\n            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);\n            cout << m << \"" + y +"\" << endl;\n            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);\n        }")
    elif ass == "d":
        print("        else if (x == \"" + x +"()\") {\n            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);\n            cout << d << \"" + y +"\" << endl;\n            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);\n        }")       
    print(x + "() = " + z)
