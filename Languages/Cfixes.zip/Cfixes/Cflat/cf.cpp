#include <iostream>
#include <windows.h>
#include <list>
#include <string>
#include <fstream>
using namespace std;

int main(){
    SetConsoleTitle("CFlat");
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
    std::cout <<"Start:"<< endl;
    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    string c;
    bool inc = false; 
    std::list<string> ml;
    for (;;){
        std::getline(std::cin, c);
        ml.push_back(c);
        if (c == "using task;")
        {
        	inc = true;
		}
        if (inc == true && c == "task.run;") 
        {
            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
            std::cout << "Running..." << endl;
            SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
            for (const auto& item : ml) {
                std::cout << item << endl;  
            }
            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
            std::cout << "End" << endl;
            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);

        }
        if (inc == true && c == "task.save;") 
        { 
            char* desktopDir = getenv("USERPROFILE");
            if (!desktopDir) {
                std::cerr << "Can't saving file" << endl;
                return 1;
            }
            std::string savePath = std::string(desktopDir) + "\\Desktop\\save.cf";
            std::ofstream outfile(savePath.c_str()); 
            if (outfile.is_open()) {
                for (const auto& item : ml) {
                    outfile << item << "\n";  
                }
                outfile.close();
                SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
                std::cout << ">>Save to " << savePath << endl;
                SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
            }
        }
        if (inc == true && c == "task.read;") 
        {
        	char* desktopDir = getenv("USERPROFILE");
            if (!desktopDir) {
                std::cerr << "Can't saving file" << endl;
                return 1;
            }
            std::string savePath = std::string(desktopDir) + "\\Desktop\\save.cf";
            std::ifstream file(savePath);
            if (file.is_open()) 
            {
                std::string line;
                SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
                std::cout << "Reading..." << endl;
                SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_INTENSITY);
                while (std::getline(file, line))
                {
                std::cout << line << std::endl;
                }
            file.close();
            } else {
                std::cerr << "Failed to open file." << std::endl;
                return 1;
            }
            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY);
            std::cout << "End" << endl;
            SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        }


    }
}
